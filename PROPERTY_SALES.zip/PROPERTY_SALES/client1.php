<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Property Details</h5>
                <?php
                // Database connection settings
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "properties";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Get the record ID from the query string
                $id = intval($_GET['id']);

                // Retrieve the record from the database
                $sql = "SELECT * FROM details WHERE PropertyID = $id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "<p>Address: " . htmlspecialchars($row['Address']) . "</p>";
                    echo "<p>City: " . htmlspecialchars($row['City']) . "</p>";
                    echo "<p>State/Province: " . htmlspecialchars($row['StateProvince']) . "</p>";
                    echo "<p>Zip/Postal Code: " . htmlspecialchars($row['ZipPostalCode']) . "</p>";
                    echo "<p>Country: " . htmlspecialchars($row['Country']) . "</p>";
                    echo "<p>Land Area: " . htmlspecialchars($row['LandArea']) . "</p>";
                    echo "<p>Zoning Type: " . htmlspecialchars($row['ZoningType']) . "</p>";
                    echo "<p>Parcel Number: " . htmlspecialchars($row['ParcelNumber']) . "</p>";
                    echo "<p>Listing Price: " . htmlspecialchars($row['ListingPrice']) . "</p>";
                    echo "<p>Utilities Available: " . htmlspecialchars($row['UtilitiesAvailable']) . "</p>";
                    echo "<p>Access to Roads: " . htmlspecialchars($row['AccessToRoads']) . "</p>";
                    echo "<p>Topography: " . htmlspecialchars($row['Topography']) . "</p>";
                    echo "<p>Soil Type: " . htmlspecialchars($row['SoilType']) . "</p>";
                    echo "<p>Flood Zone: " . htmlspecialchars($row['FloodZone']) . "</p>";
                    echo "<p>Title Deed Number: " . htmlspecialchars($row['TitleDeedNumber']) . "</p>";
                    echo "<p>Survey Number: " . htmlspecialchars($row['SurveyNumber']) . "</p>";
                    echo "<p>Encumbrances: " . htmlspecialchars($row['Encumbrances']) . "</p>";
                    echo "<p>Permit Information: " . htmlspecialchars($row['PermitInformation']) . "</p>";
                    echo "<p>Image:</p>";
                    echo "<img src='" . htmlspecialchars($row['ImageURL']) . "' alt='Property Image' width=250 height=250>";
                    echo "<p>Sold: " . ($row['Sold'] ? 'Yes' : 'No') . "</p>";
                } else {
                    echo "<p>No record found for ID: $id</p>";
                }

                // Close the database connection
                $conn->close();
                ?>
                <p>These are the details of the searched property.</p>
                <p>Click below to go home page</p>
                <a href="client.php" class="btn btn-primary">Go to home page </a>
            </div>
        </div>
    </div>
</body>
</html>
