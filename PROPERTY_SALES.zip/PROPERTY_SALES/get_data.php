<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Data Retrieved from Database</title>
    <style>
        body {
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        img {
            display: block;
            margin: auto;
            width: 400px;
            height: 250px;
        }
        .property-details {
            padding: 20px;
            font-size: 14px;
        }
        .property-details p {
            margin-bottom: 10px;
        }
        .read-more {
            text-align: center;
            margin-top: 20px;
        }
        .read-more a {
            color: blue;
        }
        .sold {
            font-weight: bold;
        }
        .sold.sold {
            color: red;
        }
        .sold.available {
            color: green;
        }
        .thead-green {
            background-color: green;
            color: white;
        }
        .more-details {
            display: none;
        }
        .custom-checkbox {
            position: relative;
        }
        .custom-checkbox input[type="checkbox"] {
            opacity: 0;
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 100%;
            cursor: pointer;
        }
        .custom-checkbox span {
            display: inline-block;
            width: 18px;
            height: 18px;
            background: white;
            border: 2px solid #ddd;
            border-radius: 3px;
            position: relative;
        }
        .custom-checkbox input[type="checkbox"]:checked + span {
            background: blue;
            border-color: blue;
        }
        .custom-checkbox input[type="checkbox"]:checked + span::before {
            content: '';
            position: absolute;
            top: 2px;
            left: 6px;
            width: 4px;
            height: 10px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
    </style>
</head>
<body>
<h2>Welcome To Admin Page </h2>
    <div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
        <div class="card card-no-margin mt-4">
            <div class="card-body text-center">
                <p>To add a new record</p>
                <a href='insert.html' class='btn btn-primary'>CLICK HERE</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-no-margin mt-4">
            <div class="card-body text-center">
                <p>To update a record</p>
                <a href='update.html' class='btn btn-primary'>CLICK HERE</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-no-margin mt-4">
            <div class="card-body text-center">
                <p>To search a record</p>
                <a href='search.html' class='btn btn-primary'>CLICK HERE</a>
            </div>
        </div>
    </div>
    </div>
        <h2>The Details Of The Properties</h2>

    <?php
    // Connect to your database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "properties";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch data from your database table
    $sql = "SELECT * FROM details";
    $result = $conn->query($sql);

    // Display data in an HTML table format
    if ($result->num_rows > 0) {
        echo "<table class='table table-hover'>";
        echo "<thead class='thead-green'><tr><th>Image</th><th>Details</th><th>Sold</th></tr></thead><tbody>";
        while ($row = $result->fetch_assoc()) {
            $propertyID = htmlspecialchars($row["PropertyID"]);
            echo "<tr>";
            echo "<td><img src='" . htmlspecialchars($row["ImageURL"]) . "' alt='Image'></td>";
            echo "<td class='property-details'>";
            echo "<p>Property ID: " . $propertyID . "</p>";
            echo "<p>Address: " . htmlspecialchars($row["Address"]) . "</p>";
            echo "<p>City: " . htmlspecialchars($row["City"]) . "</p>";
            echo "<p>State/Province: " . htmlspecialchars($row["StateProvince"]) . "</p>";
            echo "<p>Zip/Postal Code: " . htmlspecialchars($row["ZipPostalCode"]) . "</p>";
            echo "<div id='more-details-" . $propertyID . "' class='more-details'>";
            foreach ($row as $key => $value) {
                if (!in_array($key, ['PropertyID', 'Address', 'City', 'StateProvince', 'ZipPostalCode', 'ImageURL', 'Sold'])) {
                    echo "<p>$key: " . htmlspecialchars($value) . "</p>";
                }
            }
            echo "</div>";
            echo "<button id='button-" . $propertyID . "' class='btn btn-primary' onclick='toggleDetails(" . $propertyID . ")'>Read More</button>";
            echo "</td>";
            echo "<td class='text-center'>";
            echo "<label class='custom-checkbox'><input type='checkbox' " . ($row['Sold'] ? 'checked' : '') . " disabled><span></span></label>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p class='text-center'>0 results</p>";
    }

    // Close the database connection
    $conn->close();
    ?>

    <script>
        function toggleDetails(propertyId) {
            var details = document.getElementById('more-details-' + propertyId);
            var button = document.getElementById('button-' + propertyId);
            if (details.style.display === 'none' || details.style.display === '') {
                details.style.display = 'block';
                button.textContent = 'Read Less';
            } else {
                details.style.display = 'none';
                button.textContent = 'Read More';
            }
        }
    </script>
</body>
</html>
