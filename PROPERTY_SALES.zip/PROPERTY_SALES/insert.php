<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "properties";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set parameters
$address = $_POST['address'];
$city = $_POST['city'];
$state_province = $_POST['state_province'];
$zip_postal_code = $_POST['zip_postal_code'];
$country = $_POST['country'];
$land_area = $_POST['land_area'];
$zoning_type = $_POST['zoning_type'];
$parcel_number = $_POST['parcel_number'];
$listing_price = $_POST['listing_price'];
$utilities_available = $_POST['utilities_available'];
$access_to_roads = $_POST['access_to_roads'];
$topography = $_POST['topography'];
$soil_type = $_POST['soil_type'];
$flood_zone = $_POST['flood_zone'];
$title_deed_number = $_POST['title_deed_number'];
$survey_number = $_POST['survey_number'];
$encumbrances = $_POST['encumbrances'];
$permit_information = $_POST['permit_information'];
$image_url = $_POST['image_url'];
$is_sold = isset($_POST['sold']) ? 1 : 0; // Convert checkbox value to 1 or 0

// Prepare the SQL statement
$sql = "INSERT INTO PropertyInfo (Address, City, StateProvince, ZipPostalCode, Country, LandArea, ZoningType, ParcelNumber, ListingPrice, UtilitiesAvailable, AccessToRoads, Topography, SoilType, FloodZone, TitleDeedNumber, SurveyNumber, Encumbrances, PermitInformation, ImageURL, Sold) 
VALUES ('$address', '$city', '$state_province', '$zip_postal_code', '$country', '$land_area', '$zoning_type', '$parcel_number', '$listing_price', '$utilities_available', '$access_to_roads', '$topography', '$soil_type', '$flood_zone', '$title_deed_number', '$survey_number', '$encumbrances', '$permit_information', '$image_url', $is_sold)";

// Execute the statement
if ($conn->query($sql) === TRUE) {
    // Redirect to the verification page if insertion is successful
    header("Location: verification_page.php");
    exit(); // Ensure that subsequent code is not executed after redirection
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>
