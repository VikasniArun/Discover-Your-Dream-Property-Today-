<?php
$servername = "localhost";
$dbusername = "root"; 
$dbpassword = ""; 
$dbname = "login"; 

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the input values and escape them to prevent SQL injection
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM login WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 0) {
        $conn->close();
        header("Location: index.php?error=Invalid username or password");
        exit();
    }

    $user = $result->fetch_assoc();

    if (password_verify($password, $login['password'])) {
        $conn->close();
        echo "Login successful!";
        // Here you can start a session, redirect to a protected page, etc.
    } else {
        $conn->close();
        header("Location: index.php?error=Invalid username or password");
        exit();
    }
}
?>
