<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the submitted username and password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Database connection settings
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $dbname = "properties";

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to fetch user credentials
    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);
    if ($username === 'admin' && $password === 'password') {
        // Login successful, redirect the user to client.php
        header("Location: get_data.php");
        exit();
    } else {
        if ($result->num_rows > 0) {
            // Login successful, redirect the user to client.php
            header("Location: client.php");
            exit();
        } else {
            // Login failed, redirect back to the login page with an error message
            header("Location: index.php?error=Invalid%20username%20or%20password");
            exit();
        }
    }
}
?>
