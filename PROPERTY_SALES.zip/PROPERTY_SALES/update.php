<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "properties";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from POST request and sanitize inputs
$id = intval($_POST['id']);
$address = $conn->real_escape_string($_POST['address']);
$city = $conn->real_escape_string($_POST['city']);
$state_province = $conn->real_escape_string($_POST['state_province']);
$zip_postal_code = $conn->real_escape_string($_POST['zip_postal_code']);
$country = $conn->real_escape_string($_POST['country']);
$land_area = $conn->real_escape_string($_POST['land_area']);
$zoning_type = $conn->real_escape_string($_POST['zoning_type']);
$parcel_number = $conn->real_escape_string($_POST['parcel_number']);
$listing_price = $conn->real_escape_string($_POST['listing_price']);
$utilities_available = $conn->real_escape_string($_POST['utilities_available']);
$access_to_roads = $conn->real_escape_string($_POST['access_to_roads']);
$topography = $conn->real_escape_string($_POST['topography']);
$soil_type = $conn->real_escape_string($_POST['soil_type']);
$flood_zone = $conn->real_escape_string($_POST['flood_zone']);
$title_deed_number = $conn->real_escape_string($_POST['title_deed_number']);
$survey_number = $conn->real_escape_string($_POST['survey_number']);
$encumbrances = $conn->real_escape_string($_POST['encumbrances']);
$permit_information = $conn->real_escape_string($_POST['permit_information']);
$image_url = $conn->real_escape_string($_POST['image_url']);
$sold = isset($_POST['sold']) ? 1 : 0;

// Construct the SQL update query
$sql = "UPDATE details SET 
            Address='$address', 
            City='$city', 
            StateProvince='$state_province', 
            ZipPostalCode='$zip_postal_code', 
            Country='$country', 
            LandArea='$land_area', 
            ZoningType='$zoning_type', 
            ParcelNumber='$parcel_number', 
            ListingPrice='$listing_price', 
            UtilitiesAvailable='$utilities_available', 
            AccessToRoads='$access_to_roads', 
            Topography='$topography', 
            SoilType='$soil_type', 
            FloodZone='$flood_zone', 
            TitleDeedNumber='$title_deed_number', 
            SurveyNumber='$survey_number', 
            Encumbrances='$encumbrances', 
            PermitInformation='$permit_information', 
            ImageURL='$image_url', 
            Sold=$sold 
        WHERE PropertyID=$id";

// Execute the query
if ($conn->query($sql) === TRUE) {
    header("Location: update_verification_page.php?id=$id");
    exit();
} else {
    echo "Error updating record: " . $conn->error;
}

// Close connection
$conn->close();
?>
