<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Edit Record</h2>

        <?php
        // Database connection settings
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "properties";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get the record ID from the query string
        $id = intval($_POST['id']);

        // Retrieve the record from the database
        $sql = "SELECT * FROM details WHERE PropertyID = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        ?>
        <form action="update.php" method="post">
    <input type="hidden" name="id" value="<?php echo $row['PropertyID']; ?>">
    <div class="form-group">
        <label for="address">Address:</label>
        <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($row['Address']); ?>" required>
    </div>
    <div class="form-group">
        <label for="city">City:</label>
        <input type="text" class="form-control" id="city" name="city" value="<?php echo htmlspecialchars($row['City']); ?>" required>
    </div>
    <div class="form-group">
        <label for="state_province">State/Province:</label>
        <input type="text" class="form-control" id="state_province" name="state_province" value="<?php echo htmlspecialchars($row['StateProvince']); ?>" required>
    </div>
    <div class="form-group">
        <label for="zip_postal_code">Zip/Postal Code:</label>
        <input type="text" class="form-control" id="zip_postal_code" name="zip_postal_code" value="<?php echo htmlspecialchars($row['ZipPostalCode']); ?>" required>
    </div>
    <div class="form-group">
        <label for="country">Country:</label>
        <input type="text" class="form-control" id="country" name="country" value="<?php echo htmlspecialchars($row['Country']); ?>" required>
    </div>
    <div class="form-group">
        <label for="land_area">Land Area:</label>
        <input type="text" class="form-control" id="land_area" name="land_area" value="<?php echo htmlspecialchars($row['LandArea']); ?>" required>
    </div>
    <div class="form-group">
        <label for="zoning_type">Zoning Type:</label>
        <input type="text" class="form-control" id="zoning_type" name="zoning_type" value="<?php echo htmlspecialchars($row['ZoningType']); ?>" required>
    </div>
    <div class="form-group">
        <label for="parcel_number">Parcel Number:</label>
        <input type="text" class="form-control" id="parcel_number" name="parcel_number" value="<?php echo htmlspecialchars($row['ParcelNumber']); ?>" required>
    </div>
    <div class="form-group">
        <label for="listing_price">Listing Price:</label>
        <input type="text" class="form-control" id="listing_price" name="listing_price" value="<?php echo htmlspecialchars($row['ListingPrice']); ?>" required>
    </div>
    <div class="form-group">
        <label for="utilities_available">Utilities Available:</label>
        <input type="text" class="form-control" id="utilities_available" name="utilities_available" value="<?php echo htmlspecialchars($row['UtilitiesAvailable']); ?>" required>
    </div>
    <div class="form-group">
        <label for="access_to_roads">Access to Roads:</label>
        <input type="text" class="form-control" id="access_to_roads" name="access_to_roads" value="<?php echo htmlspecialchars($row['AccessToRoads']); ?>" required>
    </div>
    <div class="form-group">
        <label for="topography">Topography:</label>
        <input type="text" class="form-control" id="topography" name="topography" value="<?php echo htmlspecialchars($row['Topography']); ?>" required>
    </div>
    <div class="form-group">
        <label for="soil_type">Soil Type:</label>
        <input type="text" class="form-control" id="soil_type" name="soil_type" value="<?php echo htmlspecialchars($row['SoilType']); ?>" required>
    </div>
    <div class="form-group">
        <label for="flood_zone">Flood Zone:</label>
        <input type="text" class="form-control" id="flood_zone" name="flood_zone" value="<?php echo htmlspecialchars($row['FloodZone']); ?>" required>
    </div>
    <div class="form-group">
        <label for="title_deed_number">Title Deed Number:</label>
        <input type="text" class="form-control" id="title_deed_number" name="title_deed_number" value="<?php echo htmlspecialchars($row['TitleDeedNumber']); ?>" required>
    </div>
    <div class="form-group">
        <label for="survey_number">Survey Number:</label>
        <input type="text" class="form-control" id="survey_number" name="survey_number" value="<?php echo htmlspecialchars($row['SurveyNumber']); ?>" required>
    </div>
    <div class="form-group">
        <label for="encumbrances">Encumbrances:</label>
        <input type="text" class="form-control" id="encumbrances" name="encumbrances" value="<?php echo htmlspecialchars($row['Encumbrances']); ?>" required>
    </div>
    <div class="form-group">
        <label for="permit_info">Permit Information:</label>
        <input type="text" class="form-control" id="permit_info" name="permit_info" value="<?php echo htmlspecialchars($row['PermitInformation']); ?>">
    </div>
    <div class="form-group">
        <label for="image_url">Image URL:</label>
        <input type="text" class="form-control" id="image_url" name="image_url" value="<?php echo htmlspecialchars($row['ImageURL']); ?>" required>
    </div>
    <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="sold" name="sold" value="1" <?php echo $row['Sold'] ? 'checked' : ''; ?>>
        <label class="form-check-label" for="sold">Sold</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

        <?php
        } else {
            echo "<p>No record found for ID: $id</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>
</html>
