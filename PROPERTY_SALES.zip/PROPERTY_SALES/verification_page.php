<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Verify Details</h2>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Record Details</h5>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "properties";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch the last inserted record from PropertyInfo table
                $sql = "SELECT * FROM PropertyInfo ORDER BY PropertyID DESC LIMIT 1";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "<p>Address: " . htmlspecialchars($row['Address']) . "</p>";
                    echo "<p>City: " . htmlspecialchars($row['City']) . "</p>";
                    echo "<p>State/Province: " . htmlspecialchars($row['StateProvince']) . "</p>";
                    echo "<p>Zip/Postal Code: " . htmlspecialchars($row['ZipPostalCode']) . "</p>";
                    echo "<p>Country: " . htmlspecialchars($row['Country']) . "</p>";
                    echo "<p>Land Area: " . htmlspecialchars($row['LandArea']) . "</p>";
                    echo "<p>Zoning Type: " . htmlspecialchars($row['ZoningType']) . "</p>";
                    echo "<p>Parcel Number: " . htmlspecialchars($row['ParcelNumber']) . "</p>";
                    echo "<p>Listing Price: " . htmlspecialchars($row['ListingPrice']) . "</p>";
                    echo "<p>Utilities Available: " . htmlspecialchars($row['UtilitiesAvailable']) . "</p>";
                    echo "<p>Access to Roads: " . htmlspecialchars($row['AccessToRoads']) . "</p>";
                    echo "<p>Topography: " . htmlspecialchars($row['Topography']) . "</p>";
                    echo "<p>Soil Type: " . htmlspecialchars($row['SoilType']) . "</p>";
                    echo "<p>Flood Zone: " . htmlspecialchars($row['FloodZone']) . "</p>";
                    echo "<p>Title Deed Number: " . htmlspecialchars($row['TitleDeedNumber']) . "</p>";
                    echo "<p>Survey Number: " . htmlspecialchars($row['SurveyNumber']) . "</p>";
                    echo "<p>Encumbrances: " . htmlspecialchars($row['Encumbrances']) . "</p>";
                    echo "<p>Permit Information: " . htmlspecialchars($row['PermitInformation']) . "</p>";
                    echo "<p>Image:</p>";
                    echo "<img src='" . htmlspecialchars($row['ImageURL']) . "' alt='Property Image' width=400 height=400>";
                    echo "<p>Sold: " . ($row['Sold'] == 1 ? 'Yes' : 'No') . "</p>";
                } else {
                    echo "<p>No record found</p>";
                }

                $conn->close();
                ?>
                <p>Please verify the details above. If everything is correct, click the button below.</p>
                <a href="get_data.php" class="btn btn-primary">Confirm</a>
            </div>
        </div>
    </div>
</body>
</html>
